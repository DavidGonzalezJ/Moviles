package es.ucm.fdi.gdv.nightmareworks.aninterface;

public interface Image {
    int getWidth();
    int getHeight();
}
